

MashupPlatform.operator.log('TEST Operator started', MashupPlatform.log.INFO);

var InputEndpoint  = MashupPlatform.operator.createInputEndpoint
(
  function (data_string) 
  {
    MashupPlatform.operator.log('Input Received', MashupPlatform.log.INFO);
    alert("InputEndpoint handler\n" + data_string);
  }
);