eProsima Fast RTPS installation requires the following steps:

1. eProsima Fast RTPS requires the installation of eProsima FastCDR library on
your system to run some of the provided examples and compile the code generated with eProsima FASTRTPSGEN.

eProsima FastCDR library is provided under the folder "requiredcomponents". Extract the content of the package "eProsima_FastCDR-1.0.6-Linux.tar.gz" and execute:

    $ cd eProsima_FastCDR-1.0.6-Linux; ./configure --libdir=/usr/lib; make; sudo make install

2. eProsima Fast RTPS also requires Boost libraries. Install them using your Linux distribution package manager.

3. Install the eProsima Fast RTPS software.

    $ cd eProsima_FastRTPS-1.3.0-Linux; ./configure --libdir=/usr/lib; make; sudo make install

For more information read the manual located in "eProsima_FastRTPS-1.3.0-Linux/share/doc/manual/index.html"
