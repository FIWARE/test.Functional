var classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes =
[
    [ "HistoryAttributes", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#a42b806f9ab4b3467a8f727aeb1e9c716", null ],
    [ "HistoryAttributes", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#a78a828653de2e23e149623461b9b157b", null ],
    [ "~HistoryAttributes", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#aee15bbed758f7dd42af3badc0f1d7a11", null ],
    [ "initialReservedCaches", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#ac2353bc927f035c867ecb1fe45155a99", null ],
    [ "maximumReservedCaches", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#a06f22dd60fd75b32b70d90ab9a28973d", null ],
    [ "memoryPolicy", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#a7a1f9ed0e132ef37e4b08ad9c5584028", null ],
    [ "payloadMaxSize", "classeprosima_1_1fastrtps_1_1rtps_1_1_history_attributes.html#a238d2343bc8a76ce2938f33385396102", null ]
];