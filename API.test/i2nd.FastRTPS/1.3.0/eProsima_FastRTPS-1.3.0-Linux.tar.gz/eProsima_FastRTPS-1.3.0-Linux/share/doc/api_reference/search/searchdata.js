var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvw~",
  1: "abcdefghilmnopqrstuw",
  2: "e",
  3: "abcdefghiklmnopqrstuw~",
  4: "abcdefghiklmnopqrstuvw",
  5: "bcdeflmoprstuv",
  6: "cdehklmoprt",
  7: "abcdegiklmnprstvw",
  8: "demnoprsw",
  9: "cefnprstw",
  10: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Modules",
  10: "Pages"
};

